package J06007;

import java.util.Objects;

public class MonHoc {
    private String ma;
    private String ten;

    public MonHoc(String ma, String ten) {
        this.ma = ma;
        this.ten = ten;
    }
}
